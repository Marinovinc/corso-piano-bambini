# Canzoncine per bambini al pianoforte — guida

`[sessione 3c88c123, 04/10/2026]` — corso della serie, stessa formula. Arrangiamenti facilissimi a
due mani (melodia a destra, accordi a sinistra), per **Synthesia**.

Sono filastrocche tradizionali di **pubblico dominio**, in **DO maggiore** (solo tasti bianchi):
perfette per i primi passi, per i bambini e per i genitori che vogliono suonare con loro. Melodie
prese da notazione e **verificate all'ascolto**; arrangiamento semplice e originale.

**Regola d'oro: prima la mano sinistra, da sola, lenta.** Qui gli accordi sono pochissimi (spesso
solo DO e SOL7): si imparano in un attimo.

---

## I brani (5, tutti in DO)

| # | File | Note |
|---|---|---|
| 1 | `1_Twinkle_Twinkle` | Twinkle Twinkle Little Star (Brilla brilla stellina) |
| 2 | `2_Mary_Had_a_Little_Lamb` | tre note vicine: ideale per iniziare |
| 3 | `3_Fra_Martino` | Fra Martino / Frère Jacques (si puo' fare a canone!) |
| 4 | `4_Row_Row_Row_Your_Boat` | la "merrily merrily" scende come un arpeggio di DO |
| 5 | `5_Hot_Cross_Buns` | solo **tre note** (mi-re-do): il primo brano in assoluto |

Ogni brano ha il suo **MP3** di ascolto. I tempi sono tranquilli; in Synthesia puoi rallentare ancora.

---

## Consigli per insegnare ai bambini

- **Comincia da Hot Cross Buns** (solo mi-re-do): si impara in cinque minuti e da' subito
  soddisfazione.
- Fai **cantare** il bambino mentre suona: l'orecchio guida le dita.
- Poche ripetizioni e tante pause: a quest'eta' la costanza breve batte le sessioni lunghe.
- Fra Martino si puo' suonare **a canone** in due: uno comincia, l'altro entra dopo una frase.

---

## Onesta' sui file

Filastrocche di pubblico dominio, prese da notazione e verificate all'ascolto; arrangiamento
semplicissimo e originale, mani separate, tutto su tasti bianchi. Pensate per i primissimi passi al
pianoforte. Buon divertimento, e un tasto alla volta.
